#ifndef _SYSCONVERT_H_
#define _SYSCONVERT_H_

unsigned char BCD_toDEC(unsigned char bcd);
int ContrastData(unsigned char *dat1, unsigned char *dat2, int len);
void D_To_Str(unsigned long dat, unsigned char *buf);
#endif
