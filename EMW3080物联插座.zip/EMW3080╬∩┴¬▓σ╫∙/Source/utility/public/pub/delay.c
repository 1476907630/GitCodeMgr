#include <intrins.h>

#include "Delay.h"

/*
 * 功能 		：延时1ms函数
 * 返回值 	：无返回值
 */
void Delay1ms(void)		//@11.0592MHz 
{
	unsigned char i, j;

	_nop_();
	i = 11;
	j = 190;
	do
	{
		while (--j);
	} while (--i);
}

/*
 * 功能 		：延时(x)ms函数
 * 返回值 	：无返回值
 */
void Delay_ms(unsigned int i)
{
	while(i!=0)
	{
		i--;
		Delay1ms();		
	}	
}

/*
 * 功能 		：延时10ms函数
 * 返回值 	：无返回值
 */
void Delay10ms(void)		//@11.0592MHz
{
	unsigned char i, j;

	_nop_();
	_nop_();
	i = 108;
	j = 144;
	do
	{
		while (--j);
	} while (--i);
}

/*
 * 功能 		：延时100ms函数
 * 返回值 	：无返回值
 */
void Delay100ms(void)		//@11.0592MHz
{
	unsigned char i, j, k;

	i = 5;
	j = 52;
	k = 195;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}


/*
 * 功能 		：延时1微秒函数
 * 返回值 	：无返回值
 */
void Delay1us(void)		//@11.0592MHz
{
	_nop_();
}


/*
 * 功能 		：延时x微秒函数
 * 返回值 	：无返回值
 */
void Delay_us(unsigned int i)
{
	while(i!=0)
	{
		i--;
		Delay1us();		
	}	
}


/*
 * 功能 		：延时10微秒函数
 * 返回值 	：无返回值
 */
void Delay10us(void)		//@11.0592MHz
{
	unsigned char i;

	_nop_();
	_nop_();
	_nop_();
	i = 24;
	while (--i);
}


/*
 * 功能 		：延时100微秒函数
 * 返回值 	：无返回值
 */
void Delay100us(void)		//@11.0592MHz
{
	unsigned char i, j;

	i = 2;
	j = 15;
	do
	{
		while (--j);
	} while (--i);
}
