#ifndef __DELAY_H
#define __DELAY_H

void Delay1ms(void);		//@11.0592MHz
void Delay_ms(unsigned int); //@11.0592MHz
void Delay10ms(void);		//@11.0592MHz
void Delay100ms(void);		//@11.0592MHz
void Delay1us(void);		//@11.0592MHz
void Delay_us(unsigned int i); //@11.0592MHz
void Delay10us(void);		//@11.0592MHz
void Delay100us(void);		//@11.0592MHz

#endif
